# @funcef-componentes/auth

Autenticação padrão dos sistemas FUNCEF — **um pacote, dois cenários de consumo**.
`better-auth` existe **só** atrás de `/server` e `/auth-client`; todos os outros
entries são better-auth-free (invariante garantido por testes de import-graph).

## Qual é o seu cenário?

**Seu sistema tem login próprio?**

- **Não** → **Cenário 1 — Consumidor TKF2** (a maioria; sistemas legados). O login
  acontece na porta de entrada (`web-autenticacao`), que grava o cookie `TKF2` em
  `.funcef.com.br`; seu sistema só o consome.
- **Sim** → **Cenário 2 — Full BA (Entra ID)** (sistemas novos). Sessão própria via
  `createFuncefAuth`, login exclusivamente Microsoft Entra ID. Sem TKF2.

> A **porta de entrada** (`web-autenticacao`) é o único sistema que EMITE o TKF2
> (credenciais .NET + MFA por e-mail + Entra). O módulo `legacy` da factory existe
> só para ela — ver [docs/classes.md](./docs/classes.md).

## Instalação

```bash
pnpm add @funcef-componentes/auth
# Cenário 2 também instala o peer:
pnpm add better-auth   # faixa suportada: >=1.6.22 <2
```

## Quickstart — Cenário 1 (Consumidor TKF2)

```ts
// src/proxy.ts — bounce de UX para a porta de entrada (cross-origin + continue)
import { createSessionProxy } from '@funcef-componentes/auth/proxy';
import { TKF2_COOKIE_NAME } from '@funcef-componentes/auth';

export const proxy = createSessionProxy({
  publicRoutes: [],
  sessionCookieNames: [TKF2_COOKIE_NAME],
  signInPath: 'https://web-autenticacao.funcef.com.br/entrar', // URL absoluta + ?continue=
});
```

```ts
// api.ts — cliente HTTP isomórfico (browser E servidor), sem axios
import { createApi } from '@funcef-componentes/auth/http';
export const api = createApi({ baseURL: process.env.NEXT_PUBLIC_API_URL! });
```

```tsx
// Server Component (SSR): token por chamada, request-scoped
import { cookies } from 'next/headers';
import { TKF2_COOKIE_NAME } from '@funcef-componentes/auth';

const tkf2 = (await cookies()).get(TKF2_COOKIE_NAME)?.value;
const { data } = await api.get<Relatorio[]>('/relatorios', { token: tkf2 });
```

## Quickstart — Cenário 2 (Full BA, Entra ID)

```ts
// core/auth.ts
import { createFuncefAuth } from '@funcef-componentes/auth/server';

export const auth = createFuncefAuth({
  secret: process.env.BETTER_AUTH_SECRET!,
  baseURL: process.env.APP_URL!,
  microsoft: { clientId, clientSecret, tenantId, audience },
  // sem `legacy` — não existe TKF2 nem endpoint de credenciais neste cenário
});
```

```ts
// app/api/auth/[...all]/route.ts
import { toNextJsHandler } from '@funcef-componentes/auth/server';
import { auth } from '@/core/auth';
export const { GET, POST } = toNextJsHandler(auth);
```

## Entries

| Import         | Conteúdo                                                                                       | Guia                       |
| -------------- | ---------------------------------------------------------------------------------------------- | -------------------------- |
| `.`            | tipos + helpers puros (`User`/`Menu`/`MenuGroup`/`System`, `safeContinue`, `TKF2_COOKIE_NAME`) | [types](./docs/types.md)   |
| `/http`        | `createApi` isomórfico (browser + SSR), normalizers, erro carimbado, `endSession`              | [http](./docs/http.md)     |
| `/client`      | superfície React (`SessionGuards`, `AuthErrorListener`) + `DEFAULT_SESSION_COOKIE_NAMES`       | [client](./docs/client.md) |
| `/server`      | `createFuncefAuth`, DAL (`createRequireSession`), `onAuthEvent`                                | [server](./docs/server.md) |
| `/auth-client` | plugins do `authClient` do better-auth (browser, só Cenário 2/porta de entrada)                | [client](./docs/client.md) |
| `/proxy`       | `createSessionProxy` (bounce otimista; suporta porta de entrada cross-origin)                  | [proxy](./docs/proxy.md)   |
| `/shell`       | `AppShell` (chrome props-in: menu agrupado, guards de sessão embutidos, busca)                 | [shell](./docs/shell.md)   |

## Variáveis de ambiente

```bash
# .env.example — Cenário 1
NEXT_PUBLIC_API_URL=        # API .NET do SEU sistema (valida o TKF2 por chamada)

# .env.example — Cenário 2
BETTER_AUTH_SECRET=         # segredo do better-auth
APP_URL=                    # URL base absoluta da app
AUTH_MICROSOFT_CLIENT_ID=
AUTH_MICROSOFT_CLIENT_SECRET=
AUTH_MICROSOFT_TENANT_ID=
AUTH_MICROSOFT_AUDIENCE=

# Porta de entrada (adicional ao Cenário 2)
AUTH_API_URL=               # URL do backend .NET de AUTH (NÃO é a URL da app!)
```

## Segurança (resumo)

- **A fronteira é o dado, não o proxy** — `createRequireSession` (DAL) / API .NET validando
  TKF2 por chamada; o `/proxy` é só bounce de UX.
- **Token request-scoped** (`createApi`) — sem singleton mutável; no servidor, `token`
  por chamada.
- **TKF2**: dono único (`tkf2-lifecycle`), `maxAge = session.expiresIn`, desliza no
  `/get-session`, morre no `/sign-out`. Nome fixo (`TKF2_COOKIE_NAME`).

Ver [guia de segurança](./docs/security.md) e [ciclo do TKF2](./docs/tkf2-lifecycle.md).
