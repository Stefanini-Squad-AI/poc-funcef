# `@funcef-componentes/auth/http`

Núcleo HTTP **isomórfico** da lib — substitui o combo axios + interceptors dos
sistemas. Roda igual em Server Component / Server Action / Route Handler e no
browser, **sem** o banner `"use client"` (nenhum React aqui). Uma instância por
backend, via `createApi`.

## Browser × servidor

| Aspecto | Browser                                              | Servidor                                                                             |
| ------- | ---------------------------------------------------- | ------------------------------------------------------------------------------------ |
| Token   | `getToken` da instância (`createApi({ getToken })`)  | `token` **por chamada** (`api.get(url, { token })`), request-scoped                  |
| 401     | dispara `AUTH_ERROR_EVENT` → teardown (via listener) | evento NÃO dispara (window-guarded); o erro carimbado é **lançado** e o caller trata |
| Cookies | `credentials: 'include'` (envia o cookie de sessão)  | inócuo — não há cookie de browser no contexto do servidor                            |

O contrato de saída é sempre o mesmo dos dois lados: sucesso resolve
`ApiResponse<T>`; falha **lança** o erro carimbado por `buildApiError`.

## Exemplo SSR completo

```tsx
// Server Component (SSR): token por chamada, request-scoped
import { cookies } from 'next/headers';
import { createApi } from '@funcef-componentes/auth/http';
import { TKF2_COOKIE_NAME } from '@funcef-componentes/auth';

const api = createApi({ baseURL: process.env.NEXT_PUBLIC_API_URL! });

export default async function RelatoriosPage() {
  const tkf2 = (await cookies()).get(TKF2_COOKIE_NAME)?.value;
  const { data } = await api.get<Relatorio[]>('/relatorios', { token: tkf2 });

  return <RelatoriosList relatorios={data} />;
}
```

No servidor, **nunca** mute um `let` global para guardar o token — cada request
concorrente lê `cookies()` da sua própria requisição e passa `token` por chamada.
Isso é o que fecha o C1 (vazamento de token entre requests em SSR).

## `createApi(config)`

```ts
import { createApi } from '@funcef-componentes/auth/http';

const api = createApi({
  baseURL: env.API_URL,
  getToken: () => authClient.getAccessToken(), // browser; no servidor prefira `token` por-chamada
  normalize: funcefEnvelope, // default; ver "Normalizers"
  timeoutMs: 30_000, // default
});
```

### BFF como alternativa recomendada (Cenário 2)

O exemplo acima resolve o Bearer **no browser** (`getToken` chamando
`authClient.getAccessToken()`) — token-mediating, expõe o token ao runtime da
página (vetor bearer-in-browser, ver [security.md](./security.md)). Para
dados pessoais/financeiros, prefira o BFF same-origin: `createBffHandler`
(`/server`) resolve o Bearer **no servidor**, a partir da sessão `httpOnly`, e
nunca o entrega ao JS do browser.

```ts
// app/api/backend/[...path]/route.ts
import { createBffHandler } from '@funcef-componentes/auth/server';
import { auth } from '@/core/auth/server';

export const { GET, POST, PUT, PATCH, DELETE } = createBffHandler(auth, {
  upstreamUrl: env.API_URL,
  providerId: 'microsoft',
});
```

`createBffHandler` é o **caminho recomendado** do Cenário 2. `createApi({ getToken })`
fica como fallback para os casos que um proxy same-origin não cobre bem —
streaming e chamadas de alto volume, onde o round-trip extra pelo BFF pesa
mais.

### Config

- `baseURL: string` — URL base absoluta; os paths das chamadas (`get`/`post`/...)
  são relativos a ela.
- `getToken?: () => Promise<string | null>` — getter de token **por instância**.
  No servidor, prefira `options.token` por-chamada.
- `normalize?: Normalize` — normalizador do envelope do backend → `ApiResponse<T>`.
  Default: `funcefEnvelope`. **Vale também para o corpo de erro** — o mesmo
  normalizer da instância é usado para normalizar o payload de erro (4xx/5xx).
- `timeoutMs?: number` — timeout por chamada (via `AbortSignal.timeout`). Default
  `30_000` (30s). Timeout **não** é abort do caller: o erro resultante tem
  `isRetryable(err) === true`.

### Fachada `Api`

```ts
interface Api {
  get: <T>(url: string, options?: RequestOptions) => Promise<ApiResponse<T>>;
  post: <T, D = unknown>(url: string, data?: D, options?: RequestOptions) => Promise<ApiResponse<T>>;
  put: <T, D = unknown>(url: string, data?: D, options?: RequestOptions) => Promise<ApiResponse<T>>;
  patch: <T, D = unknown>(url: string, data?: D, options?: RequestOptions) => Promise<ApiResponse<T>>;
  delete: <T>(url: string, options?: RequestOptions) => Promise<ApiResponse<T>>;
}
```

`RequestOptions` por chamada: `signal?` (AbortController), `headers?`, e `token?`
(sobrepõe o `getToken` da instância — use no servidor).

## Normalizers

O contrato de saída de qualquer chamada via `createApi` é sempre o mesmo,
independente do envelope do backend:

```ts
type ApiResponse<T> = {
  success: boolean;
  message: string | null;
  data: T;
  blocked: boolean | null;
  totalRecords: number | null;
  notificationCode: string | null;
};
```

- `funcefEnvelope` (**default**): converte o envelope FUNCEF `.NET`
  (`{ resultado, mensagem, qtdRegistros, codNotificacao }`) em `ApiResponse<T>`.
  Respostas sem esse formato caem em passthrough (o valor vira `data`).
- `passthrough`: embrulha qualquer JSON cru em `ApiResponse<T>` sem interpretar
  envelope — use para backends REST que não falam o formato FUNCEF.
- `Normalize` customizado — escreva o seu quando o backend tem um envelope
  próprio:

```ts
import { createApi, type Normalize } from '@funcef-componentes/auth/http';

const meuEnvelope: Normalize = (raw) => ({
  success: true,
  message: (raw as { msg?: string })?.msg ?? null,
  data: (raw as { payload?: unknown })?.payload ?? null,
  blocked: null,
  totalRecords: null,
  notificationCode: null,
});

const api = createApi({ baseURL: env.OUTRA_API_URL, normalize: meuEnvelope });
```

O `normalize` da instância vale tanto para respostas de sucesso quanto para o
corpo de erro (`buildApiError` reusa o mesmo normalizer para extrair `message`
do payload de falha).

## Erro carimbado

`buildApiError` lança um erro carimbado com metadados de retry/toast (via
`Symbol`, à prova de minificação):

```ts
import { stampApiError, isRetryable, getToastMessage, type ApiErrorMeta } from '@funcef-componentes/auth/http';
```

- `isRetryable(err)` — `true` para 5xx, falha de rede ou timeout; `false` para
  4xx e abort explícito do caller.
- `getToastMessage(err)` — mensagem para toast (ou `null` quando o erro não deve
  toastar).
- 401 dispara `AUTH_ERROR_EVENT` **no browser** (`typeof window !== 'undefined'`);
  no servidor o evento não dispara — o caller trata o erro lançado.

## Teardown (`endSession` / `createSessionTeardown`)

```ts
import { endSession, createSessionTeardown, type EndSessionDeps } from '@funcef-componentes/auth/http';
```

Orquestrador **puro/injetável** de encerramento de sessão — não conhece
Better Auth nem nenhum adapter concreto. Ordem: logout remoto (best-effort) →
limpa cookies do servidor → limpa estado client-side → redirect. Se a limpeza
de cookies falhar, aborta **sem** redirecionar (evita loop com o `/proxy`, que
considera a sessão válida pela presença do cookie).

`createSessionTeardown(deps)` devolve um runner com guarda anti-reentrância em
escopo de módulo — 401 global e idle-logout compartilham o mesmo encerramento
e não disparam dois redirects concorrentes.

## `AUTH_ERROR_EVENT`

Nome do `CustomEvent` disparado no browser em resposta 401. Consumido pelo
`AuthErrorListener` do `/client` — não precisa ouvir diretamente na maioria dos
casos.

## `/client` não reexporta este núcleo

`/client` traz só a superfície React (`AuthProviders`, `AuthErrorListener`,
`SessionGuards`) + `DEFAULT_SESSION_COOKIE_NAMES`. Importe `createApi`,
normalizers, erro carimbado, teardown e `AUTH_ERROR_EVENT` sempre daqui
(`/http`) — inclusive em código `"use client"`, já que este entry é isomórfico
e não carrega o banner.
