# `@funcef-componentes/auth/shell`

Entry de UI — chrome padrão do template FUNCEF. BA-free. Dados **props-in** (a lib
não busca; o consumidor injeta).

## `AppShell`

Chrome visual: sidebar (SystemSwitcher no topo + menu agrupado, até 2 níveis por
item), header (busca + alertas + ações) e área de conteúdo com título +
breadcrumb derivados. Guards de sessão embutidos quando `logout` é injetado.
Acessível (aria-current/expanded/hidden, aria-live, `prefers-reduced-motion`).

### Casca mínima

```tsx
<AppShell menu={menu} user={user} app={{ name: 'web-template' }} logout={logout}>
  {children}
</AppShell>
```

Isso já monta sidebar + header + busca (Ctrl/⌘+K) + título/breadcrumb derivados +
footer institucional + guards de sessão (idle/offline) + listener de 401 — nada
disso exige props adicionais.

### Props (`AppShellProps`)

- `menu?: MenuGroup[]` — menu agrupado (ausente = modo login, sem sidebar). Ver
  [Menu agrupado](#menu-agrupado-menugroup) abaixo.
- `user?: User` — usuário autenticado (nav-user/footer). `image` ausente ativa o
  fallback de iniciais.
- `app?: AppIdentity` — identidade da aplicação (`{ name, version?, subtitle? }`). Ver
  [Identidade da aplicação](#identidade-da-aplicação-app).
- `systems?: System[]` — sistemas FUNCEF do `SystemSwitcher` no header da
  sidebar. Ausente → o header da sidebar exibe só a identidade (`app.name`),
  **não-interativa** (botão sem dropdown/ação). Cada `System` tem `icon?`
  (nome Lucide; sem ele, cai no fallback de inicial) e `group?` (agrupamento
  de negócio, opcional); o clique navega para `url` (via `linkResolver`).
- `alerts?: React.ReactNode` — slot de alertas no header.
- `logout?: () => void` — teardown de sessão injetado. Presente → monta os
  [guards embutidos](#guards-embutidos-logout-onautherror-guards).
- `onAuthError?: () => void | Promise<void>` — handler do 401
  (`AuthErrorListener`). Default: `logout`.
- `guards?: false | { idleTimeoutMs?: number; idleCountdownSeconds?: number }` —
  `false` desliga **apenas** o `SessionGuards` (idle/offline); **não** afeta o
  `AuthErrorListener` do 401 (esse depende só de `logout`/`onAuthError`, ver
  [Guards embutidos](#guards-embutidos-logout-onautherror-guards)). Objeto
  configura o idle. Default: ligado quando há `logout`.
- `search?: boolean` — `false` desliga a paleta de busca (Ctrl/⌘+K). Default
  (`true`/ausente): ligada quando há menu.
- `linkResolver?: (link: string) => string` — traduz um `link`/`url` de menu
  para a rota Next correspondente.
- `breadcrumb?: React.ReactNode` — override do bloco derivado de título +
  breadcrumb.
- `headerActions?: React.ReactNode` — ações à direita da linha utilitária do
  header (depois da busca e dos alertas).
- `sidebarActions?: React.ReactNode` — slot na sidebar, logo abaixo do
  `SystemSwitcher` e antes do `NavMain`.
- `footer?: React.ReactNode | false` — substitui o footer institucional;
  `false` remove.
- `children: React.ReactNode` — conteúdo da página.

### Menu agrupado (`MenuGroup[]`)

> **BREAKING (0.5.0):** `menu` era `Menu[]`; agora é `MenuGroup[]`. Migração:
> `menu={[{ items: menuAntigo }]}` — um único grupo sem `label`, com os mesmos
> itens de antes.

```ts
type MenuGroup = {
  label?: string;
  items: Menu[];
};
```

`MenuGroup` é um nível de agrupamento visual (`SidebarGroupLabel`) **acima** dos
2 níveis do `Menu` — `label` ausente renderiza os itens do grupo soltos, sem
cabeçalho. Ícones: `Menu.icon` é o **nome de um ícone Lucide** (ex.: `'home'`,
`'folder'`), resolvido pela lib via `DynamicIcon` (`lucide-react/dynamic`; peer
`lucide-react >=0.447.0`).

```tsx
const menu: MenuGroup[] = [
  { items: [{ label: 'Início', icon: 'home', url: '/' }] }, // sem label → itens soltos
  {
    label: 'Cadastros',
    items: [
      { label: 'Clientes', icon: 'users', url: '/clientes' },
      {
        label: 'Configurações',
        icon: 'settings',
        subs: [{ label: 'Perfis', url: '/configuracoes/perfis' }],
      },
    ],
  },
];
```

Itens com `subs` (grupo colapsável) auto-expandem quando contêm a rota ativa;
fechar o grupo manualmente tem **precedência** sobre essa auto-expansão —
navegar para outro sub-item depois não reabre o grupo sozinho.

### Identidade da aplicação (`app`)

```ts
type AppIdentity = {
  name: string;
  version?: string;
  subtitle?: string;
};
```

Usada em dois lugares do chrome:

- **Sidebar header** — logo + `app.name` + subtítulo abaixo
  (`app.subtitle`; default `"SISFUNCEF"`).
- **Footer institucional** (`ShellFooter`) —
  `Copyright © {ano} FUNCEF - Fundação dos Economiários Federais | Sistema {app.name} v{app.version}`.
  `version` é opcional (o ` v{app.version}` some quando ausente); o ano é
  sempre o corrente (`new Date().getFullYear()`).

Sem `app`, nem o bloco de identidade da sidebar nem o footer institucional são
renderizados.

### Busca (command palette)

Com `menu` presente, o header ganha um trigger de busca (`Ctrl+K` em
Windows/Linux, `⌘K` no macOS) que abre uma paleta central: busca por label nos
itens do menu (sub-itens aparecem como `"Item pai → Sub-item"`) e, ao
selecionar, navega para a rota resolvida (`linkResolver`) e fecha.
`search={false}` desliga o recurso inteiro (trigger + atalho de teclado).

### Breadcrumb derivado

A trilha de breadcrumb do header é **derivada** automaticamente de
`(menu, pathname)` — o último nível é a página atual (`BreadcrumbPage`); não há
título grande separado (a página cuida do próprio `<h1>`). O **label do grupo**
(`MenuGroup.label`) **não** entra na trilha — é só um cabeçalho visual da
sidebar:

- Home (rota resolvida de `/`) e rotas **fora do menu** → nada é renderizado (a
  página cuida do próprio cabeçalho, ou usa o slot `breadcrumb`).
- Rota de um item de 1º nível → trilha `Início › Item`.
- Rota de um sub-item (2º nível) → trilha `Início › Item pai › Sub-item`.
- O label de "Início" é o de um item do menu cuja `url` resolvida seja a raiz
  (`/`), se existir; caso contrário, "Página Inicial".
- No mobile, níveis intermediários colapsam num `⋯` com dropdown.

`breadcrumb?: React.ReactNode` substitui o bloco inteiro (título + trilha) por
um conteúdo próprio — útil em rotas fora do menu que precisam de cabeçalho
customizado. A troca é feita com `??` (`breadcrumb ?? <ShellBreadcrumb ... />`):
`breadcrumb={false}` **suprime** o bloco derivado (nada é renderizado);
`breadcrumb={null}` **não** suprime — `null` é nullish, então cai no fallback e
o bloco derivado continua sendo exibido.

### `headerActions` e `sidebarActions`

`headerActions?: React.ReactNode` renderiza à direita da linha utilitária do
header (depois da busca e dos alertas) — livre para qualquer ação própria do
app (ex.: notificações, atalhos).

`sidebarActions?: React.ReactNode` renderiza na sidebar, logo abaixo do
`SystemSwitcher` e antes do `NavMain`.

### Troca de tema

Não existe um `ThemeToggle` separado nem um entry `/shell/theme-toggle` — a
troca de tema (Claro/Escuro/Sistema) é um **submenu "Tema"** dentro do
`NavUser` (rodapé da sidebar), sempre presente quando há `user`. O submenu usa
`useTheme()`/`setTheme()` do **`next-themes`**, que por isso é um **peer
dependency obrigatório** do pacote (`>=0.4.0`, não mais opcional).

O app precisa montar um `ThemeProvider` do `next-themes` acima do `AppShell` —
o `NavUser` só consome `useTheme()`, não monta o provider:

```tsx
import { ThemeProvider } from 'next-themes';
import { AppShell } from '@funcef-componentes/auth/shell';

<ThemeProvider attribute="class" defaultTheme="system" enableSystem>
  <AppShell menu={menu} user={user} logout={logout}>
    {children}
  </AppShell>
</ThemeProvider>;
```

### `footer`

O footer institucional (`ShellFooter`, derivado de `app`) é o default.
`footer` substitui esse comportamento: passe um `React.ReactNode` para trocar o
conteúdo, ou `false` para remover o footer inteiramente.

### Guards embutidos (`logout`, `onAuthError`, `guards`)

O `AppShell` monta dois mecanismos **independentes entre si**:

- `AuthErrorListener` — ouve o 401 emitido pelo `/client` e chama
  `onAuthError ?? logout`. Monta sempre que **qualquer um** dos dois for
  informado — inclusive com `onAuthError` sozinho, sem `logout`. **Não** é
  afetado por `guards`.
- `SessionGuards` — aviso de inatividade (idle, com countdown) + overlay de
  offline + banner de conexão ruim. Monta só quando `logout` está presente
  **e** `guards !== false`.

Nenhuma prop adicional é necessária: a casca mínima (`menu`, `user`, `app`,
`logout`) já cobre login + guards de sessão. Para customizar:

- `onAuthError?: () => void | Promise<void>` — troca o handler do 401 (default
  `logout`); mantém o `AuthErrorListener` ativo mesmo sem `logout`.
- `guards={false}` — desliga **apenas** o `SessionGuards`; o
  `AuthErrorListener` do 401 continua ativo se `logout`/`onAuthError` estiver
  presente (útil se o app já monta seu próprio idle/offline, mas ainda quer o
  teardown automático no 401).
- `guards={{ idleTimeoutMs, idleCountdownSeconds }}` — configura o aviso de
  inatividade (defaults: 5 min / 30 s).

Sem `logout` **e** sem `onAuthError`, nada é montado (nem listener, nem
guards) — é o caso de telas públicas/login.

### Exemplo completo

```tsx
<AppShell
  menu={menu}
  user={user}
  app={{ name: 'web-template', version: '3.0.0' }}
  systems={systems}
  logout={logout}
  guards={{ idleTimeoutMs: 10 * 60_000 }}
  sidebarActions={<QuickCreateButton />}
  headerActions={<NotificationsButton />}
>
  {children}
</AppShell>
```

### Mapeamento do backend → tipos canônicos

O consumidor é responsável por adaptar os dados do backend para os tipos da lib:

```ts
// Identity backend → User
const user: User = {
  id: String(identity.Id),
  name: identity.Nome,
  email: identity.Email ?? '',
  image: identity.Foto,
};

// SystemEntry backend → System
const systems: System[] = backendSystems.map((s) => ({
  name: s.Nome,
  url: s.Link,
  group: s.GrupoNegocios?.[0]?.Nome,
}));
```

## Componentes internos

- `NavMain` — navegação principal (`MenuGroup[]`, ≤2 níveis com Collapsible,
  `aria-current`). Interno, não exportado do barrel.
- `NavUser` — avatar + dropdown de perfil no SidebarFooter: submenu "Tema"
  (Claro/Escuro/Sistema, via `next-themes`) e "Sair" (`logout`). Interno, não
  exportado do barrel.
- `SystemSwitcher` — identidade + seletor de sistemas no header da sidebar
  (padrão team-switcher; sem `systems` vira identidade estática). Interno, não
  exportado do barrel.
- `Alerts` — container de apresentação de alertas no header. Interno, não
  exportado do barrel.
- `MenuCommandPalette` — paleta de busca do menu (Ctrl/⌘+K). Interno, não
  exportado do barrel.
- `ShellBreadcrumb` — título + trilha derivados de `(menu, pathname)`. Interno,
  não exportado do barrel.
- `ShellFooter` — footer institucional derivado de `app`. Interno, não
  exportado do barrel.

## Não faça

- Não busque dados dentro do `/shell` — injete `menu`/`user`/`systems` por prop.
- Não trate a UI como fonte de verdade de sessão; a detecção do 401 é do
  `/client` — o `AppShell` só ouve o evento e chama o `logout`/`onAuthError`
  injetado.
- Não use o `AppShell` sem um `ThemeProvider` (`next-themes`) montado no app —
  o submenu "Tema" do `NavUser` depende de `useTheme()`.
