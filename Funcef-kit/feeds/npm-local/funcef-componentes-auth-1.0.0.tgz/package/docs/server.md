# `@funcef-componentes/auth/server`

Entry **server-only** (marcado com `server-only`) — requer `better-auth` como
peerDependency. É a **única** superfície que importa `better-auth`.

## `createFuncefAuth(config)`

Fábrica de autenticação FUNCEF (Modo B). Monta Core sempre e Legacy **opt-in**;
`nextCookies()` sempre por último.

### Config (principais campos)

- `secret: string` — segredo do Better Auth.
- `baseURL: string` — URL base absoluta da app.
- `basePath?: string` — base path (ex.: `/sistema-x`).
- `microsoft: MicrosoftProviderConfig` — provider EntraID (`clientId`,
  `clientSecret`, `tenantId`, `audience`, `scopes?`, `profilePhoto?`,
  `profilePhotoSize?` — ver "Foto de perfil").
- `secondaryStorage?` — Redis opcional (`redisStorage({ client })`).
- `photoStore?` — store de fotos; ausente reusa o `secondaryStorage` quando `microsoft.profilePhoto` liga (ver "Foto de perfil").
- `legacy?` — módulo Legacy opt-in: `{ authApiUrl, endpoints?, timeoutMs?, tkf2? }`.
- `trustedProxyHeaders?: boolean` — BA 1.7: confiar em `X-Forwarded-Host`. Default
  `false` (sempre emitido explícito).
- `session?: SessionAgeConfig` — ver "Sessão configurável" abaixo.
- `onAuthEvent?: AuthEventHandler` — ver "Observabilidade" abaixo.
- `errorRedirectPath?: string` — rota da app (ex.: `'/sign-in'`) para onde os
  erros de fluxo do Better Auth redirecionam com `?error=<code>` (ex.:
  `state_mismatch` quando o cookie de state do callback Entra
  expirou/sumiu — janela de login parada, cookies limpos no meio do fluxo).
  A tela de login mapeia o código para mensagem amigável ("Sua tentativa de
  login expirou. Tente novamente."). Omitido → página interna do BA
  (`/api/auth/error`).

### Exemplo (Cenário 2 — Full BA, Core só)

```ts
export const auth = createFuncefAuth({
  secret: env.AUTH_SECRET,
  baseURL: env.APP_URL,
  basePath: '/api/auth',
  microsoft: {
    clientId: env.MS_CLIENT_ID,
    clientSecret: env.MS_CLIENT_SECRET,
    tenantId: env.MS_TENANT,
    audience: env.MS_AUDIENCE,
  },
  session: { expiresIn: 60 * 60 * 24 * 7 },
});
```

### Exemplo (Porta de entrada — Core + Legacy)

`AUTH_API_URL` é a URL do **backend .NET de auth** (não é a URL da app — ver
"Endpoints do backend .NET configuráveis" abaixo):

```ts
export const auth = createFuncefAuth({
  secret: env.AUTH_SECRET,
  baseURL: env.APP_URL,
  basePath: '/api/auth',
  microsoft: {
    /* ... */
  },
  session: { expiresIn: 60 * 60 * 24 * 7 },
  secondaryStorage: redisStorage({ client: redis }),
  legacy: {
    authApiUrl: env.AUTH_API_URL,
    tkf2: { domain: '.funcef.com.br', secure: true },
  },
});
```

## Sessão configurável

```ts
interface SessionAgeConfig {
  /** TTL da sessão. Default 7 dias (`60*60*24*7`). */
  expiresIn?: number;
  /** Janela de renovação da sessão. Default 24h. */
  updateAge?: number;
  /** Idade máxima para operações "fresh". Default 5min. */
  freshAge?: number;
}
```

Passe via `session` na config da factory. `expiresIn` é a fonte única do TTL — o
cookie TKF2 (Cenário 1 via porta de entrada) **herda o mesmo valor** em `maxAge`,
garantindo que sessão e TKF2 nascem e expiram juntos.

```ts
export const auth = createFuncefAuth({
  // ...
  session: { expiresIn: 60 * 60 * 24 * 3 }, // 3 dias, por exemplo
});
```

Omitido → defaults atuais (7 dias / 24h / 5min).

## Endpoints do backend .NET configuráveis

Os paths dos endpoints do backend .NET de auth (o `AUTH_API_URL` — URL do
backend .NET de auth, **não** a URL da app) são configuráveis por prop, nunca
fixos no pacote:

```ts
interface FuncefAuthEndpoints {
  login: string; // Default '/Login'
  validarMfa: string; // Default '/Login/ValidarMFA'
  solicitarMfa: string; // Default '/Login/SolicitarMFA'
  mintToken: string; // Default '/Login/MintToken'
}
```

`DEFAULT_FUNCEF_AUTH_ENDPOINTS` (interno) traz os defaults acima. Sobrescreva via
`legacy.endpoints` (parcial) — a factory constrói o backend internamente:

```ts
import { createFuncefAuth } from '@funcef-componentes/auth/server';

export const auth = createFuncefAuth({
  // ...
  legacy: {
    authApiUrl: env.AUTH_API_URL,
    endpoints: { login: '/Auth/Login' }, // só sobrescreve o que muda; o resto vem do default
    timeoutMs: 10_000, // default; timeout das chamadas verify/resend/mint ao .NET
  },
  onAuthEvent: (event) => logger.warn(event.type, event.detail),
});
```

`timeoutMs` (default `10_000`) é o timeout das três chamadas ao .NET
(`verify`/`resend`/`mint`) feitas pelo backend adapter (construído internamente
pela factory a partir de `legacy.authApiUrl`).

## Observabilidade

`onAuthEvent?: AuthEventHandler` é um _seam_ de eventos discretos, best-effort:
exceções do handler são engolidas (telemetria nunca pode quebrar login/sessão).
Sem detail com PII (nunca inclui usuário/senha). Passe **uma única vez**, na
config raiz da factory — é a **fonte única**: a mesma função é threadada tanto
para o `funcef-credentials`/`tkf2-lifecycle` quanto para o backend de
credenciais que a factory constrói internamente a partir de `legacy.authApiUrl`
(cobrindo também `backend.timeout`, de `verify`/`resend`/`mint` ao .NET).

```ts
export const auth = createFuncefAuth({
  // ...
  legacy: { authApiUrl: env.AUTH_API_URL, tkf2: { secure: true } },
  onAuthEvent: (event) => {
    // event: { type, detail? } — cobre credentials.invalid, tkf2.slide,
    // tkf2.mint.failed, backend.timeout (verify/resend/mint ao .NET) e
    // cookie.overweight (Set-Cookie do login acima de 8KB)
    metrics.increment(`auth.${event.type}`);
  },
});
```

| `type`                | Quando dispara                                                                                                                                                                |
| --------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `tkf2.mint.failed`    | O mint do `tokenAcesso` TKF2 (callback Entra) falhou.                                                                                                                         |
| `tkf2.slide`          | O slide do TKF2 no `/get-session` foi executado.                                                                                                                              |
| `credentials.invalid` | Login por credenciais FUNCEF rejeitado pelo backend .NET.                                                                                                                     |
| `backend.timeout`     | Uma chamada ao backend .NET (`verify`/`resend`/`mint`) excedeu `timeoutMs`.                                                                                                   |
| `cookie.overweight`   | O login (credenciais ou callback Entra) emitiu mais de 8KB de `Set-Cookie` — alarme antecipado de HTTP 431/436 (ver [security.md](./security.md), "Troubleshooting 431/436"). |

## DAL (Data Access Layer)

### `createRequireSession(auth, options?)`

**Fronteira de segurança real** do Modo B. Fábrica memoizada por request
(`React.cache`) que devolve um resolvedor: resolve a sessão e **redireciona**
para o login se ausente. Use junto do dado (Server Component / Route Handler /
Server Action). O retorno nunca é `null`.

```ts
const requireSession = createRequireSession(auth);
const session = await requireSession(); // redireciona antes se ausente
```

### `createGetServerSession(auth)`

Fábrica memoizada por request (`React.cache`) que devolve um resolvedor da
sessão sem garantia de presença (pode retornar `null`).

```ts
const getServerSession = createGetServerSession(auth);
const session = await getServerSession();
```

## Handler

### `toNextJsHandler(auth)`

Monta o catch-all único `app/api/auth/[...all]/route.ts`.

```ts
// app/api/auth/[...all]/route.ts
import { toNextJsHandler } from '@funcef-componentes/auth/server';
import { auth } from '@/core/auth/server';

export const { GET, POST } = toNextJsHandler(auth);
```

## Módulo Legacy

Peças internas — `createFuncefAuth` as monta quando `legacy` é informado;
nenhuma delas é exportada do barrel `/server`:

- `funcefCredentials({ backend, tkf2?, onAuthEvent? })` — plugin BA: registra
  `POST /sign-in/funcef-credentials` e `POST /funcef-credentials/resend-mfa`.
- O adapter que agrega `verify` (`/Login` + `/Login/ValidarMFA`), `resend`
  (`/Login/SolicitarMFA`) e `mint` (`/Login/MintToken`, callback Entra) sob o
  MESMO host .NET é construído **internamente** pela factory a partir de
  `legacy.authApiUrl` (+ `legacy.endpoints?`/`legacy.timeoutMs?`) — não é mais
  uma função exportada; ver "Endpoints do backend .NET configuráveis" acima.
- `tkf2Lifecycle` / `createEntraTkf2Mint` — ciclo do cookie TKF2 (slide no
  `/get-session`, mint no callback Entra via o backend construído acima,
  expiração no `/sign-out`). O plugin `tkf2Lifecycle` é o **dono único** do
  ciclo completo do TKF2. Ver [tkf2-lifecycle](./tkf2-lifecycle.md).

## Redis

O `RedisLikeClient` casa com os overloads do `ioredis`, então um cliente
`ioredis` cru entra **direto** no adaptador abaixo — sem wrapper na app.
Ele aceita `{ client, keyPrefix? }` (default `'funcef-auth:'`).

### `redisStorage(options)`

Adapta um `RedisLikeClient` para o contrato `SecondaryStorage` do Better Auth.
Quando o cliente injetado suporta `incr`/`expire`/`getdel`, o storage expõe
`increment`/`getAndDelete` (prontidão BA 1.7).

```ts
secondaryStorage: redisStorage({ client: redis }),
```

## Custódia de tokens (Entra)

Tokens do Entra **nunca** viajam em cookie — nem o `refresh_token`, nem o access
token. Isso elimina o HTTP 431/436 causado pelas claims de grupo do Entra
(usuários em muitos grupos incham o token, e historicamente era o cookie que o
carregava que estourava os headers).

- **Com Redis** (`secondaryStorage: redisStorage({ client })`): a factory monta
  também um adapter de `database` sobre o MESMO cliente Redis — a conta OAuth
  (`user`/`account`/`verification`) passa a viver lá; a sessão continua no
  `secondaryStorage` (comportamento nativo do Better Auth quando os dois
  coexistem). Headers de login: **~2,5KB**, independentes do nº de grupos do
  usuário.
- **Sem Redis**: só o `refresh_token` (opaco, tamanho estável) viaja num cookie
  magro dedicado (`funcef-auth.rt`, `HttpOnly`, ~3KB) — gravado no callback Entra
  e expirado no `sign-out` por um plugin interno (`tokenVault`). Headers de
  login: **~5,5KB**.

Em qualquer um dos dois modos, o **access token nunca é persistido**: é mintado
sob demanda a partir do refresh token custodiado (Redis ou cookie magro) e
cacheado em memória por réplica pelo TTL do próprio token — `getAccessToken`/
`createBffHandler` continuam funcionando sem tocar cookie.

Medições, o endpoint dev-only `/debug/cookies` e o evento `cookie.overweight`
(diagnóstico e alarme do 431/436): ver [security.md](./security.md), seção
"Troubleshooting 431/436".

## Foto de perfil

O plugin `profile-photo` é **built-in** (sempre montado) e serve a foto do usuário
em `GET /profile-photo`, resolvida **sob demanda** (nunca no login — o callback
Entra fica mais rápido), em cascata:

1. **Browser** — `Cache-Control` (1h, com `stale-while-revalidate`) + `ETag`/`304`.
2. **Store/Redis** (7 dias) — quando `photoStore`/`secondaryStorage` existe.
3. **Microsoft Graph** — `/me/photos/{size}x{size}/$value`, com um token do
   Graph resolvido a partir do `refresh_token` custodiado (ver "Custódia de
   tokens" acima).

A chave é o **`oid`** do usuário (âncora imutável do Entra — o e-mail é
mutável/reciclável). Sem foto no Graph, um `404` fica **cacheado por 5min**
(negativo) — evita bater no Graph a cada request de quem não tem foto. A foto
**nunca** entra na sessão/cookie — o peso do base64 estouraria os headers —,
por isso o provider Microsoft nunca devolve a foto no `image` do perfil (fica
sempre `undefined`).

Para a foto **funcionar**, um requisito:

- **`microsoft.profilePhoto: true`.** Liga o endpoint para de fato buscar no
  Graph quando a foto não está em cache. Best-effort: falha na foto (rede,
  permissão, tamanho indisponível) nunca derruba o login nem o endpoint.

  ```ts
  microsoft: {
    // ...
    profilePhoto: true,
  },
  ```

  > **Não precisa de `User.Read` nos `scopes`.** O token de LOGIN não muda — a
  > troca do `refresh_token` pelo token do Graph acontece à parte (sob demanda,
  > só quando o endpoint é chamado), então não há colisão `AADSTS70011` mesmo
  > quando `microsoft.scopes` carrega `${audience}/.default` (cenário
  > legado/central). Os pré-requisitos são `User.Read` **consentido no app
  > registration** (tenant/admin consent) e `offline_access` no login (dá o
  > `refresh_token` que sustenta a busca) — sem o consent, a busca falha em
  > silêncio e a foto simplesmente não aparece (degradação graciosa).

**Store é OPCIONAL** — por padrão a foto reusa o `secondaryStorage`
(`redisStorage({ client: redis })`) quando ele existe; passe `photoStore`
explícito para um store separado. O Redis é um **acelerador de cache
compartilhado entre réplicas**, não um pré-requisito: sem nenhum store, a foto
ainda funciona via Graph a cada request, só sem esse cache.

No app, aponte o `image` do usuário para a **URL do endpoint** (não o base64) —
o `<Avatar>` do `/shell` cai nas iniciais quando o endpoint dá `404`:

```ts
// identity resolvido server-side para o AppShell:
image: `${basePath}/api/auth/profile-photo`,
```

## Não faça

- Não importe este entry de Client Components (`server-only` falha o build).
- Não proteja dados apenas com o `/proxy` — use `createRequireSession` (DAL).
