# TKF2 cookie — ciclo de vida

> Módulo: `packages/auth/src/server/plugins/tkf2.ts`
> Interno — `createFuncefAuth` monta este plugin quando `legacy` é informado.
> Apenas `TKF2_COOKIE_NAME` é reexportado (público) em `server/index.ts`.

## O que é o TKF2

Cookie browser-readable (`httpOnly: false`) que expõe o `tokenAcesso` do `.NET`
para apps FUNCEF no mesmo domínio (ex.: portais em `*.funcef.com.br`). A ausência
de `httpOnly` é intencional e é o motivo de existir do cookie.

## Fluxos do ciclo de vida

### 1 — Nascimento via credenciais FUNCEF

```
POST /sign-in/funcef-credentials
  → backend.verify() → { status: 'ok', tokenAcesso: 'TKF2-abc' }
  → funcefCredentials plugin: setTkf2(ctx, tokenAcesso, tkf2Config)
  → Set-Cookie: TKF2=TKF2-abc; Max-Age=604800; Path=/; SameSite=Lax
```

### 2 — Nascimento via callback Entra ID (Microsoft)

```
GET /callback/microsoft  (after hook via tkf2Lifecycle)
  → backend.mint(ctx)   // backend construído internamente a partir de legacy.authApiUrl; = createEntraTkf2Mint(authApiUrl)
    → ctx.getAccessToken('microsoft') → 'ms-access-token'
    → POST {AUTH_API_URL}/Login/MintToken  { Authorization: Bearer ms-access-token }
    → { resultado: { Auth: { TokenAcesso: 'TKF2-xyz' } } }
  → setTkf2(ctx, 'TKF2-xyz', tkf2Config)
  → Set-Cookie: TKF2=TKF2-xyz; Max-Age=604800; Path=/; SameSite=Lax
```

### 3 — Slide no /get-session

```
GET /get-session  (after hook via tkf2Lifecycle)
  → hasValidSession(ctx): verifica ctx.context.returned, ou getSessionFromCtx(ctx)
  → se há sessão: slideTkf2(ctx, cfg) re-grava o MESMO valor com maxAge renovado
  → Set-Cookie: TKF2=<valor-atual>; Max-Age=604800; Path=/; SameSite=Lax
```

A abordagem é **slide por re-emissão** (spec P5, abordagem A): o servidor relê o
valor do cookie enviado pelo browser e o regrava com `maxAge` renovado. Não há
round-trip ao `.NET` (`FuncefEngine.VerificarToken` é no-op).

### 4 — Expiração no sign-out

```
POST /sign-out  (after hook via tkf2Lifecycle)
  → expireTkf2(ctx, tkf2Config)
  → Set-Cookie: TKF2=; Max-Age=0; Path=/; SameSite=Lax
```

## Alinhamento de TTL (spec P4)

`SESSION_EXPIRES_IN = 604800` (7 dias) é a fonte única compartilhada entre
`session.expiresIn` e `Tkf2Config.maxAge` na factory. Cookie e sessão nascem e
morrem no mesmo instante.

## API interna

`tkf2Lifecycle`, `createEntraTkf2Mint`, `setTkf2`, `slideTkf2`, `expireTkf2` e os
tipos `Tkf2Config`/`MintFn`/`Tkf2MintCtx` vivem em `./plugins/tkf2` mas **não**
são reexportados do barrel `/server` — são montados internamente por
`createFuncefAuth`. Apenas o cookie name é público:

```ts
import { TKF2_COOKIE_NAME } from '@funcef-componentes/auth/server';
```

### `Tkf2Config`

```ts
interface Tkf2Config {
  domain?: string; // ex.: '.funcef.com.br'. Omitir → escopo ao host.
  secure?: boolean; // Espelhe useSecureCookies da auth.
  maxAge: number; // Max-Age em segundos (= session.expiresIn).
}
```

### `tkf2Lifecycle(cfg, mint?, onAuthEvent?)`

Plugin Better Auth, dono único do ciclo de vida do TKF2. Registra:

- hook `after` em `/get-session` para o slide (sempre).
- hook `after` em `/sign-out` para a expiração (sempre — credenciais ou Microsoft).
- hook `after` em `/callback/microsoft` para o mint Entra (somente se `mint` passado).

`onAuthEvent` é o seam de observabilidade: emite `tkf2.slide` quando o slide
acontece e `tkf2.mint.failed` quando o mint resolve `null`.

**Deve ser registrado ANTES de `nextCookies()`.**

### `createEntraTkf2Mint(baseUrl, mintTokenPath?, timeoutMs?, onAuthEvent?)`

Retorna um `MintFn` que chama `POST {baseUrl}{mintTokenPath}` (default
`/Login/MintToken`) com o Bearer do Entra e extrai `resultado.Auth.TokenAcesso`.
Best-effort: qualquer falha retorna `null` — o login Entra não é interrompido.
`timeoutMs` controla o timeout da chamada HTTP (default
`DEFAULT_FUNCEF_BACKEND_TIMEOUT_MS`); em timeout, `onAuthEvent` emite
`backend.timeout` (`detail: { op: 'mint' }`).

> Em geral você **não** chama esta função direto: `createFuncefAuth` já a embute
> como `backend.mint` ao construir o backend internamente a partir de
> `legacy.authApiUrl`, garantindo que o mint use o MESMO host .NET
> (`AUTH_API_URL`) de `verify`/`resend`. A factory consome esse `backend.mint`
> — nunca a `baseURL` da app (que não expõe `/Login/MintToken`).

### `setTkf2 / slideTkf2 / expireTkf2`

Funções de baixo nível para cenários customizados. Em geral não precisam ser
chamadas diretamente — `funcefCredentials` e `tkf2Lifecycle` cobrem todos os
fluxos padrão.

## Uso na factory

```ts
// create-funcef-auth.ts (extrato relevante)
const SESSION_EXPIRES_IN = 60 * 60 * 24 * 7; // 604800 s

const tkf2Config: Tkf2Config = {
  domain: secureCookies ? cookieDomain : undefined,
  secure: secureCookies,
  maxAge: SESSION_EXPIRES_IN,
};

// Fonte única: a factory constrói o backend internamente a partir de
// `legacy.authApiUrl`, threando o PRÓPRIO `onAuthEvent`.
const backend = legacy
  ? createFuncefCredentialsBackend(legacy.authApiUrl, {
      endpoints: legacy.endpoints,
      timeoutMs: legacy.timeoutMs,
      onAuthEvent: config.onAuthEvent,
    })
  : null;

plugins: [
  funcefCredentials({ backend, tkf2: tkf2Config, onAuthEvent: config.onAuthEvent }),
  // O mint vem do backend construído acima (`backend.mint`), ligado ao host
  // .NET (`legacy.authApiUrl`) — nunca à baseURL da app.
  tkf2Lifecycle(tkf2Config, backend.mint, config.onAuthEvent),
  nextCookies(), // DEVE ser o último plugin
];
```

## Injeção customizada do mint (seam interno)

`tkf2Lifecycle` aceita um `MintFn` customizado como 2º argumento — é o seam que
`createFuncefAuth` usa internamente para plugar `backend.mint`. Não é mais
exposto pelo barrel `/server` (API fechada, baseada em `createFuncefAuth`);
documentado aqui só para quem mexe no código-fonte da factory:

```ts
// dentro de create-funcef-auth.ts, importando direto do módulo fonte:
import { tkf2Lifecycle, type MintFn } from '../plugins/tkf2';

const myMint: MintFn = async (ctx) => {
  const at = await ctx.getAccessToken('microsoft');
  if (!at) return null;
  // lógica customizada
  return 'meu-token';
};

// na lista de plugins, antes de nextCookies():
tkf2Lifecycle(tkf2Config, myMint),
```

## Notas de segurança

- `httpOnly: false` é deliberado — o TKF2 deve ser lido por JS cross-subdomain.
  Nunca altere para `true` sem entender o impacto nos portais consumidores.
- O domínio cross-subdomain (`.funcef.com.br`) só é ativado em produção
  (`secureCookies: true`). Em desenvolvimento o cookie fica restrito ao `localhost`.
- O slide (abordagem A) depende de o browser enviar o TKF2 em cada `get-session`.
  Se o browser bloquear o cookie (ex.: políticas SameSite estritas), o slide
  retorna `false` silenciosamente — sem efeito colateral.

## Aceite de risco (S3)

A combinação `httpOnly: false` + domínio amplo (`.funcef.com.br`) + slide de
7 dias **sem validação server-side** (`FuncefEngine.VerificarToken` é no-op,
ver "Fluxos do ciclo de vida" acima) é um **risco aceito** do contrato de SSO
legado, não um bug pendente: é a troca deliberada que faz o TKF2 funcionar
como token de sessão cross-subdomain para os portais `.NET` legados.

- **Caminho de hardening** (fora do escopo desta lib, do lado `.NET`):
  encurtar o TTL efetivo do `tokenAcesso` no backend `.NET` (o `maxAge` do
  cookie pode continuar em 7 dias — é UX, não segurança do token) e
  reativar `FuncefEngine.VerificarToken` no lado que hoje trata a validação
  como no-op.
- **Pré-condições para aceitar o risco como está**: governança de subdomínio
  (só apps FUNCEF confiáveis em `*.funcef.com.br` — um subdomínio
  comprometido lê o TKF2 de todos os outros) e uma CSP que restrinja de onde
  scripts podem rodar nesses portais.
- **Dívida registrada, com rota de saída**: migrar os consumidores do TKF2
  para a sessão do Better Auth (Cenário 2) elimina a necessidade do cookie
  `httpOnly: false` — a rota de saída é essa migração, não um ajuste pontual
  no TKF2.
