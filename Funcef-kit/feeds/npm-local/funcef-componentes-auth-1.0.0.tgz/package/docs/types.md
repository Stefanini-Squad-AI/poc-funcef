# `@funcef-componentes/auth` (entry `.`)

Entry neutro — **sem** React, `next/server`, ou `better-auth`. Seguro em qualquer
contexto (client, server, proxy). É o entry-folha: importável de qualquer camada
sem puxar dependências pesadas.

## Tipos de domínio

### `User`

```ts
type User = {
  id: string;
  name: string;
  email: string;
  image?: string;
};
```

Usuário autenticado — contrato mínimo e backend-agnóstico consumido pelo `/shell`
(nav-user / footer). O consumidor mapeia a identidade do backend dele para este
shape. `image` ausente ativa o fallback de iniciais (`getInitials`).

### `Menu`

```ts
type Menu = {
  label: string;
  icon?: string;
  url?: string;
  subs?: Omit<Menu, 'subs'>[];
};
```

Item de menu com **2 níveis em compile-time** (o `Omit` proíbe um 3º nível pelo
tipo). Sem `subs` = botão (`url`); com `subs` = grupo (Collapsible).

```ts
const menu: Menu[] = [
  { label: 'Início', icon: 'home', url: '/' },
  { label: 'Cadastros', icon: 'folder', subs: [{ label: 'Clientes', url: '/clientes' }] },
];
```

O `AppShell.menu` (`/shell`) não recebe `Menu[]` diretamente — recebe `MenuGroup[]`
(ver abaixo), que agrupa itens `Menu` sob um `label` opcional.

### `MenuGroup`

```ts
type MenuGroup = {
  label?: string;
  items: Menu[];
};
```

Nível de agrupamento visual (`SidebarGroupLabel`) **acima** dos 2 níveis do
`Menu` — é o tipo que o `AppShell.menu` (`/shell`) efetivamente recebe.
`label` ausente renderiza os itens do grupo soltos, sem cabeçalho.

```ts
const menu: MenuGroup[] = [
  { items: [{ label: 'Início', icon: 'home', url: '/' }] }, // sem label → itens soltos
  {
    label: 'Cadastros',
    items: [{ label: 'Clientes', icon: 'folder', url: '/clientes' }],
  },
];
```

### `System`

```ts
type System = {
  name: string;
  url: string;
  icon?: string;
  group?: string;
};
```

Entrada do `SystemSwitcher` (dropdown do header da sidebar do `/shell`).
`icon` é o nome de um ícone **Lucide** (kebab-case, ex.: `'home'`), resolvido
via `DynamicIcon`; sem `icon`, cai no fallback de inicial do nome. `group` é
um agrupamento de negócio, opcional.

### `AppIdentity`

```ts
type AppIdentity = {
  name: string;
  version?: string;
  subtitle?: string;
};
```

Identidade da aplicação consumidora, consumida pelo `AppShell.app` (`/shell`):
exibida no header da sidebar (logo + `name` + `subtitle`, default
`"SISFUNCEF"`) e no footer institucional. `version` é opcional — some do
footer quando ausente.

### `VerifyResult` / `VerifyFn` / `ResendFn`

```ts
type VerifyResult =
  | { status: 'ok'; user: User; tokenAcesso: string }
  | { status: 'mfa_email_sent' }
  | { status: 'invalid'; mensagem?: string };
```

Contratos puros de verificação de credenciais contra o backend .NET. União
discriminada por `status`; MFA é **por e-mail** (`mfa_email_sent`, não TOTP/QR).
`VerifyFn`/`ResendFn` são os _seams_ injetados no adapter de backend do `/server`.

## Tipos de envelope HTTP

### `ApiResponse<T>`

```ts
type ApiResponse<T> = {
  success: boolean;
  message: string | null;
  data: T;
  blocked: boolean | null;
  totalRecords: number | null;
  notificationCode: string | null;
};
```

Contrato de saída fixo de toda chamada via `createApi`. `success` reflete o HTTP
2xx do transporte — **não** o desfecho de negócio (que pode chegar em 200 via
`notificationCode`).

### `BackendApiResponse<T>`

Envelope cru do backend FUNCEF (.NET). Entrada do normalizador `funcefEnvelope`.
Não use diretamente em features — consuma `ApiResponse<T>`.

## Helpers puros

### `safeContinue(url, fallback)`

Retorno seguro do redirect otimista: aceita paths relativos (`/`) e URLs absolutas
em `funcef.com.br`; descarta o resto (defesa contra open-redirect).

```ts
safeContinue('/clientes', '/'); // '/clientes'
safeContinue('https://evil.com', '/'); // '/'  (host externo barrado)
```

### `getInitials(fullName)`

Deriva até 2 iniciais maiúsculas de um nome para o avatar-fallback.

```ts
getInitials('Maria Silva'); // 'MS'
getInitials('João'); // 'J'
getInitials(null); // ''
```

## Constantes

### `DEFAULT_SESSION_COOKIE_NAMES`

```ts
const DEFAULT_SESSION_COOKIE_NAMES = [
  'better-auth.session_token',
  '__Secure-better-auth.session_token',
  // token-vault (custódia sem Redis)
  'funcef-auth.rt',
  '__Secure-funcef-auth.rt',
] as const;
```

Nomes de cookie de sessão padrão do Better Auth. Os dois primeiros são do Better
Auth; `funcef-auth.rt`/`__Secure-funcef-auth.rt` são o cookie de refresh token do
token-vault (custódia sem Redis) — incluídos aqui para que o proxy/teardown os
limpe junto com a sessão. Importável de `.` e `/proxy` sem puxar React/better-auth.

## Não faça

- Os aliases legados `Identity`/`MenuItem`/`SystemEntry` foram **removidos** — use
  `User`/`Menu`/`System` diretamente. O consumidor mapeia o backend dele para esses
  tipos (veja `shell.md` para exemplo de mapeamento).
