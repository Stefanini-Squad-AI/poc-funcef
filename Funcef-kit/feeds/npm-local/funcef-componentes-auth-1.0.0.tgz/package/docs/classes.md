# Dois cenários de consumo (+ porta de entrada)

Um pacote, dois cenários. A pergunta que decide qual é o seu: **seu sistema tem
login próprio?** O modo é escolhido pela **entrada importada**, não por branch
de código.

- **Não** → **Cenário 1 — Consumidor TKF2** (a maioria; sistemas legados). Sem
  Better Auth; consome o cookie `TKF2` emitido pela porta de entrada.
- **Sim** → **Cenário 2 — Full BA (exclusivo Entra ID)** (sistemas novos). Sessão
  própria via `createFuncefAuth`, login exclusivamente Microsoft Entra ID.

A **porta de entrada** (`web-autenticacao`) é um caso especial do Cenário 2: ela
usa o módulo `legacy` da factory para EMITIR o TKF2 (credenciais .NET + MFA por
e-mail, além do Entra) — nenhum outro sistema deve montar `legacy`.

## Cenário 1 — Consumidor TKF2 (sem Better Auth)

```ts
// Sem /server. Só /http (+/client, /shell, /proxy).
import { createApi } from '@funcef-componentes/auth/http';

// TKF2 (.funcef.com.br) auto-enviado por credentials:'include' — sem getToken.
export const api = createApi({ baseURL: env.LEGACY_API_URL });
```

Login/logout delegados à porta de entrada (`web-autenticacao`). `better-auth`
**não** é instalado.

## Porta de entrada (`web-autenticacao`)

```ts
import { createFuncefAuth, redisStorage } from '@funcef-componentes/auth/server';

// AUTH_API_URL: URL do backend .NET de auth — NÃO é a URL da app.
export const auth = createFuncefAuth({
  secret: env.AUTH_SECRET,
  baseURL: env.APP_URL,
  basePath: '/api/auth',
  microsoft: {
    clientId: env.MS_CLIENT_ID,
    clientSecret: env.MS_CLIENT_SECRET,
    tenantId: env.MS_TENANT,
    audience: env.MS_AUDIENCE,
  },
  session: { expiresIn: 60 * 60 * 24 * 7 },
  secondaryStorage: redisStorage({ client: redis }),
  legacy: {
    authApiUrl: env.AUTH_API_URL,
    tkf2: { domain: '.funcef.com.br', secure: true },
  },
});
```

Login Entra **+** credenciais/MFA-email; emite e desliza o TKF2. Único sistema
que deve configurar `legacy` — é o que EMITE o cookie que todo o Cenário 1 consome.

## Cenário 2 — Full BA (exclusivo Entra ID)

```ts
// src/core/auth/server.ts
import { createFuncefAuth } from '@funcef-componentes/auth/server';

export const auth = createFuncefAuth({
  secret: env.AUTH_SECRET,
  baseURL: env.APP_URL,
  basePath: '/api/auth',
  microsoft: {
    clientId: env.MS_CLIENT_ID,
    clientSecret: env.MS_CLIENT_SECRET,
    tenantId: env.MS_TENANT,
    audience: env.MS_AUDIENCE,
  },
  session: { expiresIn: 60 * 60 * 24 * 7 },
});
```

Sem `legacy` ⇒ zero credenciais, zero TKF2. Login exclusivamente Microsoft Entra
ID (Bearer) nos backends novos.

## Resumo

| Cenário             | Modo    | Better Auth | TKF2             | Login               |
| ------------------- | ------- | ----------- | ---------------- | ------------------- |
| 1 — Consumidor TKF2 | sem BA  | não         | consome (cookie) | porta de entrada    |
| Porta de entrada    | Full BA | Core+Legacy | emite/desliza    | Entra + credenciais |
| 2 — Full BA         | Full BA | Core        | não usa          | Entra ID (Bearer)   |
