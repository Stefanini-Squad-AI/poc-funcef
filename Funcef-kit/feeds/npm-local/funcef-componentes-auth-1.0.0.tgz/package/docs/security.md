# Segurança

Três pilares — o "o quê", o "como" e o "por quê".

## 1. Token request-scoped (fecha o C1)

`createApi` resolve o token **por request** (better-fetch `onRequest`); **não** há
singleton de módulo mutável. No servidor, passe `options.token` por-chamada —
**nunca** um `let` global mutado por request (isso É o C1: vaza token entre
requests concorrentes em SSR).

```ts
// Server (request-scoped)
const api = createApi({ baseURL: env.API_URL });
await api.get<Perfil>('/perfil', { token: await lerTokenDaRequestAtual() });
```

## 2. A fronteira é o dado, não o proxy

O `/proxy` é redirect otimista de UX e pode ser burlado (CVE-2025-29927). Proteja
**o dado**: `createRequireSession`/`createGetServerSession` (DAL, Modo B) colado ao
Server Component/route/action + o backend validando a cada request +
`401→teardown`.

```ts
// Colado ao dado — esta é a checagem que importa
const requireSession = createRequireSession(auth);
const session = await requireSession();
```

O proxy é conveniência de UX (bounce anônimo → login); nunca a única barreira.

## 3. TKF2 é cookie-only, escopado à sessão

Dono único (`tkf2-lifecycle`): nasce no mint com `maxAge = session.expiresIn`,
**desliza** a cada `/get-session` (mesmo valor, `maxAge` renovado), **morre** no
`/sign-out`. `nextCookies()` por último encaminha o `Set-Cookie`. TKF2 e sessão
expiram juntos por construção.

O nome do cookie é fixo (`TKF2_COOKIE_NAME`, exportado do entry `.`) —
configurável geraria divergência entre sistemas.

O `httpOnly: false` do TKF2 é **deliberado** — ele precisa ser lido por JS de
outras apps `.funcef.com.br`. Ver [tkf2-lifecycle](./tkf2-lifecycle.md) para o
ciclo completo.

## 4. Account-linking por e-mail (Entra + credenciais)

Login por credenciais e por Entra fundem contas pelo e-mail (diretório
corporativo único — `trustedProviders: ['microsoft']`). Isso evita duplicidade
de identidade quando o mesmo usuário acessa a porta de entrada tanto por
credenciais FUNCEF quanto por Microsoft Entra ID.

O account-linking assume um diretório corporativo único. Duas premissas que
sustentavam essa suposição são **ENFORÇADAS em código** no `getUserInfo`
custom do provider Microsoft (`entra-user-info.ts`, `makeEntraGetUserInfo`) —
instalado **incondicionalmente** (independe de `microsoft.profilePhoto`) e
rodando em **todo** login por Entra. Ele **não** busca a foto nem faz
re-exchange do Graph — a foto é resolvida sob demanda no endpoint
`GET /profile-photo`, via o resolvedor de token:

- **Guest cross-tenant rejeitado**: quando `microsoft.tenantId` é um GUID
  concreto (não `common`/`organizations`), o claim `tid` do `id_token` é
  comparado ao tenant configurado — `tid` divergente ⇒ `getUserInfo` retorna
  `null` e o login é recusado, antes de derivar `id`/`email`. Fecha o
  cenário de um guest/B2B de outro tenant logar como se fosse conta própria.
- **`emailVerified` só a partir de um claim `email` real**: `preferred_username`
  (UPN) nunca deriva `emailVerified: true` — o Microsoft trata o UPN como
  mutável/não-garantido; só um claim `email` de verdade sustenta a afirmação
  de verificação.

Ambas as checagens rodam em **todo** login por Entra, com ou sem foto de
perfil habilitada — não há caminho que as pule.

Premissas residuais, **não** enforçadas em código (aceitas como parte do
modelo, não do software): o UPN não é reciclado para outro usuário, e existe
um único tenant corporativo — a checagem de `tid` só se aplica quando
`tenantId` é um GUID concreto; com `common`/`organizations` não há tenant
único contra o qual validar.

**S4 — onde a conta OAuth mora**: `storeAccountCookie` é **sempre `false`** —
tokens do Entra (`refresh_token`, access token) **nunca** viajam em cookie.
Isso fecha, por construção, o cenário que motivou esta seção originalmente
(cookie `account_data` de ~8KB, proporcional às claims de grupo do Entra,
empurrando o request para o limite prático de cabeçalhos — HTTP 431/436).

A custódia depende de `secondaryStorage`:

- **Com Redis** (`secondaryStorage: redisStorage({ client })`): a factory monta
  também um adapter de `database` sobre o MESMO cliente Redis — `user`/
  `account`/`verification` passam a viver lá (a sessão continua no
  `secondaryStorage`, comportamento nativo do Better Auth quando os dois
  coexistem). Nada de token em cookie, em réplica alguma.
- **Sem Redis**: a conta OAuth ainda é DB-less (memória do processo, não
  sobrevive a réplica/cold start), mas isso não compromete a custódia do
  `refresh_token` — um plugin interno (`tokenVault`) grava, à parte, um
  cookie magro dedicado (`funcef-auth.rt`, `HttpOnly`, opaco, ~3KB — só o
  refresh token e chaves, nunca claims) que sobrevive entre réplicas e cold
  starts.

Em ambos os modos, o **access token nunca é persistido**: é mintado sob
demanda (a partir do refresh token do Redis ou do cookie magro) e cacheado em
memória por réplica pelo TTL do próprio token — `getAccessToken()`/
`createBffHandler` continuam funcionando pós-login sem tocar cookie.

### Troubleshooting 431/436

O sintoma histórico (antes desta custódia) era claro: usuários em muitos
grupos do Entra inflam a claim `groups` do **access token**, e o cookie
`account_data` que o carregava (dentro da conta OAuth persistida) crescia
proporcionalmente — até estourar o limite de headers do Node.

| Medição                                             | Tamanho                                                                  |
| --------------------------------------------------- | ------------------------------------------------------------------------ |
| Baseline (poucos grupos, ANTES desta custódia)      | ~10,8KB                                                                  |
| ~50 grupos do Entra no token (ANTES desta custódia) | estoura os 16.384 bytes (`maxHeaderSize` default do Node) → HTTP 431/436 |
| Headers de login hoje, **com Redis**                | ~2,5KB — independe do nº de grupos                                       |
| Headers de login hoje, **sem Redis**                | ~5,5KB — cookie magro de tamanho estável                                 |

**Diagnóstico**: `GET {basePath}/api/auth/debug/cookies` — raio-X dev-only
(responde `404` em produção) do peso de headers/cookies e dos claims do
access token (contagem de grupos, maiores claims), sem nunca expor valores.

**Alarme**: o evento `cookie.overweight` (via `onAuthEvent`) dispara quando o
login (credenciais ou callback Entra) emite mais de 8KB de `Set-Cookie` —
alarme antecipado, antes de chegar ao limite do Node.

## 5. Cenário 2 — Bearer no browser vs BFF

No Cenário 2 (Full BA, Bearer Entra ID — ver [classes](./classes.md)) há duas
formas de o browser chamar o backend novo, com superfícies de risco
diferentes.

**Token-mediating** (`createApi({ getToken: () => authClient.getAccessToken() })`):
o access token é resolvido **no browser** e anexado como `Authorization:
Bearer` a cada chamada feita por JS (ver [http.md](./http.md)). O token fica
exposto ao runtime da página — XSS, extensão maliciosa ou qualquer script de
terceiro rodando ali pode lê-lo e reutilizá-lo fora do fluxo normal. Esse é o
vetor **bearer-in-browser** (M-4).

**BFF same-origin** (`createBffHandler`, `/server`): o Bearer é resolvido **no
servidor**, dentro do route handler, a partir da sessão `httpOnly`
(`auth.api.getAccessToken`) e anexado ao upstream — o token **nunca** chega ao
JavaScript do browser, que só enxerga o cookie de sessão `httpOnly`. Fecha o
vetor bearer-in-browser por construção.

```ts
// app/api/backend/[...path]/route.ts
import { createBffHandler } from '@funcef-componentes/auth/server';
import { auth } from '@/core/auth/server';

export const { GET, POST, PUT, PATCH, DELETE } = createBffHandler(auth, {
  upstreamUrl: env.API_URL,
  providerId: 'microsoft',
});
```

**Recomendação**: para dados pessoais/financeiros, `createBffHandler` é o
**default recomendado** — a IETF _OAuth 2.0 for Browser-Based Applications_
(§6.1.4.3) recomenda fortemente ("strongly recommended") o padrão BFF para
aplicações que lidam com dados pessoais. `createApi({ getToken })` fica como
alternativa para os casos que o BFF não cobre bem (streaming, alto volume —
ver [http.md](./http.md)).
