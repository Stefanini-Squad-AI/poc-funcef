# Compatibilidade Better Auth 1.6 → 1.7

`better-auth` é **peerDependency `>=1.6.22 <2`** — o **mesmo código** roda em 1.6
e 1.7, desenhado sobre o subconjunto estável (hooks, plugins, slots nativos,
`nextCookies` por último, `toNextJsHandler`).

## O que o guia oficial diz

"Most changes are additive." As breaking changes de 1.7 estão **todas fora do
nosso escopo**: OIDC/OAuth provider, MCP (vira pacote), SCIM/SAML/Enterprise SSO,
generic-OAuth, twoFactor plugin, custom DB adapters.

> **Não confundir:** nosso EntraID é o **social provider built-in**
> (`socialProviders.microsoft`, "As a login client") — **inalterado** no 1.7 —,
> **não** o plugin "Enterprise SSO" (SAML/SCIM), cujas breaking changes não nos tocam.

## 2 itens de prontidão 1.7 (aditivos, inofensivos no 1.6)

1. **Redis `secondaryStorage`** — o 1.7 **exige** `increment(key, ttl)` +
   `getAndDelete(key)` (eram opcionais). O `redisStorage`/`RedisLikeClient` já os
   expõe (mapeados de `incr`/`expire`/`getdel` do cliente injetado). Cobre também
   rate-limit via secondary-storage.
2. **`advanced.trustedProxyHeaders`** — o 1.7 não confia em headers encaminhados
   por padrão. Ative `trustedProxyHeaders: true` na factory se a infra expõe o
   host público só via `x-forwarded-host` (nginx/Vercel/Cloudflare que reescrevem
   o host não precisam). O valor é sempre emitido explícito (default `false`), pois
   o 1.6.22 assume `?? true` quando o campo é omitido.
