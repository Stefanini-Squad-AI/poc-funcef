# `@funcef-componentes/auth/client`

Entry **client-side** (banner `"use client"`) — a superfície **React** de
autenticação (`DEFAULT_SESSION_COOKIE_NAMES` + providers/guards), **sem**
`better-auth` e **sem** o núcleo HTTP.

> O núcleo HTTP (`createApi`, normalizers, erro carimbado, teardown) mora em
> [`/http`](./http.md) — importe de lá, inclusive em código client. Este guia
> cobre o que `/client` de fato exporta: `DEFAULT_SESSION_COOKIE_NAMES` e a
> superfície React (`AuthErrorListener`, `AuthProviders`, `SessionGuards`).

## `DEFAULT_SESSION_COOKIE_NAMES`

Reexport de conveniência do entry raiz (`.`) — nomes de cookie de sessão padrão
do Better Auth. Útil para montar `sessionCookieNames` do `/proxy` sem precisar
de um import à parte da raiz:

```ts
import { DEFAULT_SESSION_COOKIE_NAMES } from '@funcef-componentes/auth/client';
```

## Providers e guards

### `AuthProviders`

**Composição opcional.** Hoje monta só o `AuthErrorListener` (que escuta
`AUTH_ERROR_EVENT`/401 e dispara o teardown injetado) — usar o listener direto é
equivalente. `AuthProviders` existe como **ponto de extensão**: se no futuro a
superfície client precisar de mais um provider, ele entra aqui sem quebrar quem
já usa o composer.

```tsx
<QueryClientProvider client={queryClient}>
  <AuthProviders onAuthError={teardown}>{children}</AuthProviders>
</QueryClientProvider>
```

Equivalente, sem o composer:

```tsx
<QueryClientProvider client={queryClient}>
  <AuthErrorListener onAuthError={teardown} />
  {children}
</QueryClientProvider>
```

### `SessionGuards`

Guardas de sessão client-side: aviso de inatividade (idle), overlay offline e banner
de conexão ruim. Acessível (aria-live / role=status). **Não é fronteira de
segurança** (isso é a DAL + 401).

```tsx
<SessionGuards logout={logout} />
```

Componível também peça a peça: `IdleWarningDialog`, `OfflineOverlay`,
`PoorConnectionBanner`, e os hooks `useIdleLogout`/`useConnectionQuality`
(`ConnectionQuality`).

> O `teardown` passado a `AuthProviders`/`AuthErrorListener` nos exemplos acima
> vem de `createSessionTeardown` — importe-o de [`/http`](./http.md), não daqui.

## Não faça

- Não instancie axios/fetch ad hoc — use sempre `createApi` (de `/http`).
- Não trate `SessionGuards` como barreira de segurança; ela é UX/a11y.
