# `@funcef-componentes/auth/proxy`

Entry **server-side** (Next 16 `proxy.ts`, roda em Node) — BA-free e React-free.

## `createSessionProxy(config)`

Redirect **otimista** por presença de cookie. **NÃO é fronteira de segurança**
(pode ser burlado — CVE-2025-29927). A barreira real é a DAL (`createRequireSession`),
mais o backend e o `401→teardown`.

### Config

- `publicRoutes: string[]` — rotas sem sessão (match `===` exato ou `startsWith(route + '/')`).
- `sessionCookieNames: string[]` — cookies que sinalizam sessão (qualquer um presente ⇒ autenticado).
- `signInPath?` — rota LOCAL (ex.: `/entrar`) **ou URL ABSOLUTA** da porta de
  entrada (ex.: `https://web-autenticacao.funcef.com.br/entrar`). Default
  **`/entrar`** (mudou de `/sign-in` — ver nota de migração abaixo).
- `continueParam?: string | false` — nome do query param anexado ao redirect
  anônimo → login com a URL COMPLETA da request original, para a porta de
  entrada devolver o usuário via `safeContinue`. Default `'continue'`; `false`
  desliga e preserva o comportamento antigo (path local mantendo a query
  original).
- `homePath?` (`/`).
- `signOutMarkerCookie?` — anti-loop no logout (enquanto presente, não rebota rota-pública → home).
- `staleSessionParam?: string | false` — anti-loop de **cookie órfão**
  (sessão inválida server-side com cookie ainda no browser — ex.: restart do
  dev server com sessões em memória). Default `'stale'`; `false` desliga.
  Ver seção abaixo.

### Cookie órfão — `staleSessionParam`

O proxy é otimista (presença-de-cookie); quem valida é a camada de dados. Se a
sessão morre no servidor mas o cookie fica no browser, o clássico pingue-pongue
acontece: layout (`getServerSession()` → nula) redireciona ao login, o proxy vê
o cookie e rebate para a home — loop infinito.

Quebra do loop em duas pontas:

1. **Camada que valida** (layout autenticado/DAL): ao encontrar sessão nula,
   redirecione ao login **com o marcador** — `redirect('/entrar?stale=1')`.
2. **Proxy**: ao ver o marcador numa rota pública com cookie de sessão, NÃO
   rebate e **apaga os cookies de sessão na resposta** (RSC não pode escrever
   `Set-Cookie`; o middleware pode). A próxima navegação chega limpa.

```ts
// layout.tsx (segmento autenticado do consumidor)
const session = await getServerSession();
if (!session) redirect('/entrar?stale=1');
```

### Nota de migração — default de `signInPath`

O default mudou de `/sign-in` para `/entrar` (alinhado à DAL). Quem depende do
comportamento antigo deve passar `signInPath: '/sign-in'` explícito.

### Exemplo — Cenário 1, login na porta de entrada (cross-origin)

```ts
// src/proxy.ts (app consumidor do Cenário 1 — sem login próprio)
import { createSessionProxy } from '@funcef-componentes/auth/proxy';
import { TKF2_COOKIE_NAME } from '@funcef-componentes/auth';

export const proxy = createSessionProxy({
  publicRoutes: [],
  sessionCookieNames: [TKF2_COOKIE_NAME],
  // URL absoluta: cross-origin para a porta de entrada. `continueParam`
  // (default 'continue') anexa a URL completa da request original.
  signInPath: 'https://web-autenticacao.funcef.com.br/entrar',
});
```

Do lado da **porta de entrada**, ao processar o login, use `safeContinue` (entry
`.`) para validar o parâmetro `continue` antes de redirecionar de volta — nunca
confie no valor bruto do query param (defesa contra open-redirect):

```ts
import { safeContinue } from '@funcef-componentes/auth';

const destino = safeContinue(searchParams.get('continue') ?? undefined, '/');
```

### Exemplo — rota local (mesma origem)

```ts
// src/proxy.ts
import { createSessionProxy } from '@funcef-componentes/auth/proxy';
import { DEFAULT_SESSION_COOKIE_NAMES } from '@funcef-componentes/auth';

export const proxy = createSessionProxy({
  publicRoutes: ['/entrar', '/recuperar'],
  sessionCookieNames: DEFAULT_SESSION_COOKIE_NAMES,
  signOutMarkerCookie: 'funcef.signing-out',
});
```

BA-free e React-free — detecção puramente por **presença de cookie**, então serve
qualquer backend (Better Auth, httpOnly custom, TKF2 do Cenário 1).

## Não faça

- **Não use o proxy como única barreira de segurança.** É redirect de UX.
- Não proteja dados sensíveis apenas com o proxy — use `createRequireSession` na DAL,
  colada ao dado, com o backend validando a cada request.
