# @funcef-componentes/cli

CLI `funcef` — cria e transforma projetos a partir do
[web-template](https://github.com/funcef/web-template), consulta o design
system e diagnostica o ambiente. **Autocontida**: os overlays de cenário
viajam dentro do pacote (`assets/`) — o template não precisa carregar
andaime de inicialização.

## Uso

```bash
pnpm dlx @funcef-componentes/cli new web-meu-sistema   # projeto novo (wizard)
pnpm dlx @funcef-componentes/cli init                  # inicializa um clone do template
pnpm dlx @funcef-componentes/cli doctor                # diagnóstico do ambiente
```

Requisitos: Node >= 22, pnpm, acesso ao GitHub FUNCEF (`gh auth login`,
`GITHUB_TOKEN` ou `~/.npmrc` com token de `npm.pkg.github.com`). Piso de
compatibilidade: **template >= 3.1.0** (para o template 3.0.0, use a
CLI 0.1.x).

Rede corporativa: se `HTTP_PROXY`/`HTTPS_PROXY` (ou minúsculas) estiverem
definidas no ambiente, a CLI honra o proxy em todas as chamadas de rede
(`NO_PROXY` é respeitado); sem elas, nada muda.

## Comandos

| Comando                                  | O que faz                                                                                                     |
| ---------------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| `new [nome]`                             | Baixa a release do template e roda o wizard completo                                                          |
| `new --template-dir <path>`              | Usa um checkout local do template em vez de baixar (ou env `FUNCEF_TEMPLATE_DIR`)                             |
| `init`                                   | Mesmo wizard, in-place, para checkout já clonado                                                              |
| `scenario list`                          | Lista os cenários (`full-ba`, `consumidor-tkf2`)                                                              |
| `scenario apply <label>`                 | Converte um checkout (`--dry-run`, `--yes`, `--verify`)                                                       |
| `scenario check` / `smoke`               | Verificadores do template (rodam no CI do repo web-template)                                                  |
| `feature <nome>`                         | Gera o contrato de uma feature — components/hooks/api/types (`--entity`, `--with-form`) num projeto já criado |
| `env check`                              | Valida o `.env.local` do projeto contra o cenário (`--scenario` força)                                        |
| `ds list` / `ds show <termo>`            | Manifest de componentes do design system (cache 24h, `--fresh`); `ds show` tem alias `ds component`           |
| `ds guide [termo]` / `ds search <termo>` | Guias de documentação do design system e busca combinada (componentes + guias)                                |
| `doctor` / `doctor --fix`                | Checklist do ambiente com dicas de correção; `--fix` oferece correções interativas para o que for corrigível  |

Flags não interativas: toda pergunta tem flag equivalente (`--scenario`,
`--name`, `--defaults`, `--yes`); em sessões não-TTY a CLI instrui qual flag
usar em vez de travar.

## Receitas e overlays

A fonte única das transformações de cenário vive em `src/recipes/`; os
arquivos de overlay do Consumidor TKF2 vivem em `assets/consumidor-tkf2/`
(cópia fiel do template). Mudou o layout do template? Atualize receita e
assets aqui e gere changeset **minor** (**major** se o `templateMajor`
mudar). O CI do template roda `funcef scenario check`/`smoke` e acusa drift.

## Estrutura

`src/commands` (borda CLI) · `src/ui` (clack) · `src/recipes` (receitas) ·
`src/template` (fluxo do web-template: download, rename, env, pipeline,
verificadores) · `src/ds` (manifests de componentes e guias) ·
`src/feature` (scaffold do contrato de feature) · `src/env-check`
(validação do `.env.local`) · `src/doctor` · `src/shared` (infra) ·
`assets/` (overlays). Testes em `__tests__/` por pasta de domínio.
