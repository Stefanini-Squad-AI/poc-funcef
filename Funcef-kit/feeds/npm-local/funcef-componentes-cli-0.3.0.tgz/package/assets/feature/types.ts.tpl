export interface __Entity__ {
  id: number;
  descricao: string;
}

export interface Create__Entity__Data {
  descricao: string;
}
