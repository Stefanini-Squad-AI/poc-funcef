import { z } from 'zod';

export const create__Entity__Schema = z.object({
  descricao: z.string().min(1, 'Descrição é obrigatória'),
});

export type Create__Entity__Input = z.infer<typeof create__Entity__Schema>;
