import { useQuery } from '@tanstack/react-query';
import { queryKeys } from '@/shared/lib';
import { __camel__Api } from '../api';

export function useAll__Pascal__() {
  const query = useQuery({
    queryKey: queryKeys.__camel__.list(),
    queryFn: () => __camel__Api.getAll(),
  });

  return {
    __camel__: query.data?.data ?? null,
    is__Pascal__Loading: query.isLoading,
    error: query.error,
  };
}
