export const endpoints = {
  list: () => '/__feature__',
  create: () => '/__feature__',
};
