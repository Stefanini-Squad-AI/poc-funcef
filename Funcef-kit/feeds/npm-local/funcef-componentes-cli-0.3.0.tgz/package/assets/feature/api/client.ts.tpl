import { api } from '@/core/api';
import { endpoints } from './endpoints';
import type { Create__Entity__Data, __Entity__ } from '../types';

export const __camel__Api = {
  getAll: () => api.get<__Entity__[]>(endpoints.list()),

  create: (data: Create__Entity__Data) =>
    api.post<__Entity__, Create__Entity__Data>(endpoints.create(), data),
};
