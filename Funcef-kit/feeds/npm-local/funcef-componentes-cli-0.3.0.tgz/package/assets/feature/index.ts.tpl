export { useAll__Pascal__ } from './hooks/use-all-__feature__';
export type { Create__Entity__Data, __Entity__ } from './types';
