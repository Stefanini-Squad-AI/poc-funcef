import 'server-only';

import { parseEnv } from '@funcef-componentes/react/env';
import { z } from 'zod';

// Cenário 1 (Consumidor TKF2): sem MICROSOFT_*/BETTER_AUTH/REDIS; adiciona
// ENTRADA_URL (porta de entrada). O backend .NET valida o cookie TKF2.
const envSchema = z.object({
  APP_URL: z
    .url('NEXT_PUBLIC_APP_URL deve ser uma URL válida')
    .default('http://localhost:3000'),

  API_URL: z.url('NEXT_PUBLIC_API_URL deve ser uma URL válida'),

  ENTRADA_URL: z.url('NEXT_PUBLIC_ENTRADA_URL deve ser uma URL válida'),

  BASE_PATH: z.string().default(''),

  NODE_ENV: z
    .enum(['development', 'production', 'test'])
    .default('development'),
});

export type Env = z.infer<typeof envSchema>;

// SEM buildFallbacks: todas as vars deste cenário são NEXT_PUBLIC_* (embarcam
// no bundle no build) — um placeholder silencioso congelaria localhost em
// produção. Faltou var no build? O build FALHA, e é o desejado.
export const env: Env = parseEnv(
  envSchema,
  {
    APP_URL: process.env.NEXT_PUBLIC_APP_URL,
    API_URL: process.env.NEXT_PUBLIC_API_URL,
    ENTRADA_URL: process.env.NEXT_PUBLIC_ENTRADA_URL,
    BASE_PATH: process.env.NEXT_PUBLIC_BASE_PATH,
    NODE_ENV: process.env.NODE_ENV,
  },
  {
    hint:
      '💡 Copie o arquivo .env.example para .env.local e preencha os valores:\n' +
      '   cp .env.example .env.local',
    varNames: {
      APP_URL: 'NEXT_PUBLIC_APP_URL',
      API_URL: 'NEXT_PUBLIC_API_URL',
      ENTRADA_URL: 'NEXT_PUBLIC_ENTRADA_URL',
      BASE_PATH: 'NEXT_PUBLIC_BASE_PATH',
    },
  }
);
