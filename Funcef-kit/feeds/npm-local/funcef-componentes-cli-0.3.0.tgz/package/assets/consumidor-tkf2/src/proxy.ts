import { createSessionProxy } from '@funcef-componentes/auth/proxy';
import { TKF2_COOKIE_NAME } from '@funcef-componentes/auth';
import { envClient } from '@/shared/config/env-client';

/**
 * Cenário 1 — Consumidor TKF2. O login NÃO acontece aqui: usuário anônimo é
 * redirecionado (cross-origin) para a porta de entrada, com `?continue=` de
 * volta. Sessão = presença do cookie `TKF2` (gravado pela porta em
 * `.funcef.com.br`). Sem rotas públicas locais (não há sign-in local).
 */
export const proxy = createSessionProxy({
  publicRoutes: [],
  sessionCookieNames: [TKF2_COOKIE_NAME],
  // URL ABSOLUTA da porta de entrada (env NEXT_PUBLIC_ENTRADA_URL) + ?continue=.
  signInPath: envClient.ENTRADA_URL,
});

export const config = {
  matcher: [
    `/((?!api/|_next/|.well-known/|.*\\.(?:png|jpg|jpeg|gif|svg|ico|webp|css|js)$).*)`,
  ],
};
