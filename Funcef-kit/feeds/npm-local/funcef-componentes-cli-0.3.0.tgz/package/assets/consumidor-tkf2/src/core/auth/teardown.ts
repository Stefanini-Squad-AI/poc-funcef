'use client';

import type { QueryClient } from '@tanstack/react-query';
import { envClient } from '@/shared/config/env-client';

interface CreateSessionTeardownOptions {
  queryClient: QueryClient;
}

/**
 * Cenário 1 — Consumidor TKF2. Não há sessão local para encerrar: limpa o
 * cache do cliente e devolve o usuário à porta de entrada (dona do logout e
 * do cookie `TKF2` em `.funcef.com.br`). MESMA assinatura do teardown Full BA
 * de propósito — é o que permite o `shell.tsx` ser único (fora do overlay).
 */
export function createSessionTeardown({
  queryClient,
}: CreateSessionTeardownOptions): () => Promise<void> {
  return async () => {
    queryClient.clear();
    window.location.href = envClient.ENTRADA_URL;
  };
}
