import 'server-only';
import { cookies } from 'next/headers';
import { TKF2_COOKIE_NAME } from '@funcef-componentes/auth';

/**
 * Cenário 1 — Consumidor TKF2. "Sessão" = presença do cookie `TKF2` (emitido
 * pela porta de entrada). NÃO valida o token aqui (isso é do backend .NET a
 * cada request); é só o guard otimista de UX para o layout autenticado.
 * O valor do token, quando preciso numa chamada SSR, é lido do mesmo cookie.
 */
export async function getTkf2Token(): Promise<string | null> {
  const jar = await cookies();
  return jar.get(TKF2_COOKIE_NAME)?.value ?? null;
}

export async function hasSession(): Promise<boolean> {
  return (await getTkf2Token()) !== null;
}
