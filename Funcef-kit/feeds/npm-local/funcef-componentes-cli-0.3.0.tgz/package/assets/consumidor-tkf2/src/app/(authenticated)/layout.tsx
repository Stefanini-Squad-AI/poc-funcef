import { redirect } from 'next/navigation';
import type { User } from '@funcef-componentes/auth';
import { hasSession } from '@/core/auth/session';
import { env } from '@/shared/config/env';
import { Shell } from './shell';

/**
 * Cenário 1 — Consumidor TKF2. Guard otimista: sem cookie TKF2 → porta de
 * entrada. O `proxy.ts` já faz esse bounce; este é a rede de segurança
 * server-side. Dados de usuário do TKF2 não são decodificados aqui (o backend
 * .NET valida a cada request) — o `AppShell` recebe um `User` mínimo.
 */
export default async function Layout({
  children,
}: {
  children: React.ReactNode;
}) {
  if (!(await hasSession())) redirect(env.ENTRADA_URL);

  // Sem perfil decodificado neste cenário; o nav-user cai nas iniciais.
  const user: User = { id: '', name: '', email: '' };

  return <Shell user={user}>{children}</Shell>;
}
