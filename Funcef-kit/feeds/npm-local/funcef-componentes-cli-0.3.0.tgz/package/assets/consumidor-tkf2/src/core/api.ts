import { createApi } from '@funcef-componentes/auth/http';
import { envClient } from '@/shared/config/env-client';

/**
 * Cenário 1 — Consumidor TKF2: fachada HTTP isomórfica sem `getToken` — no
 * browser o cookie `TKF2` viaja sozinho (`credentials: 'include'`, mesmo
 * eTLD+1 `.funcef.com.br`); no servidor, passe o token por chamada
 * (`api.get(url, { token: tkf2 })`, ver README do cenário).
 */
export const api = createApi({
  baseURL: envClient.API_URL,
});
