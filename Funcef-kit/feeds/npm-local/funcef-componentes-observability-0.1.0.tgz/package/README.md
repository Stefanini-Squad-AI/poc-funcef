# @funcef-componentes/observability

Telemetria para apps Next.js do ecossistema FUNCEF — Azure Application
Insights (browser) + OpenTelemetry → Azure Monitor (servidor).

**Inerte por padrão**: sem connection string (explícita ou via env), tudo é
no-op total — os SDKs (imports dinâmicos no servidor) nem carregam. Um app
que não quer telemetria simplesmente não instala este pacote (ou não o
configura).

## Instalação

```bash
pnpm add @funcef-componentes/observability
```

Peers: `next >= 16`, `react >= 19`. Os SDKs de telemetria são dependencies —
vêm junto, com versões curadas pela lib.

## Uso — 3 pontos de contato

### 1. Browser (provider)

Em `src/app/global-providers.tsx` (ou layout raiz):

```tsx
import { ObservabilityProvider } from '@funcef-componentes/observability';

// RECOMENDADO: passar a env explicitamente do código do app — o inline de
// NEXT_PUBLIC_* é garantido no código do próprio app; dentro de node_modules
// depende do bundler. Sem props, o pacote lê as mesmas envs como fallback.
<ObservabilityProvider
  connectionString={process.env.NEXT_PUBLIC_APPINSIGHTS_CONNECTION_STRING}
  backendUrl={process.env.NEXT_PUBLIC_API_URL}
/>;
```

Cookieless (sem `ai_user`/`ai_session`, LGPD-safe): page views anônimos,
Web Vitals (LCP/CLS/INP/FCP/TTFB), exceções, dependências fetch/AJAX e filtro
de ruído do ResizeObserver. `backendUrl` exclui o host cross-origin da
injeção de headers de correlação (preflight CORS); em BFF same-origin, omita.

### 2. Servidor (OTel)

Em `src/instrumentation.ts`:

```ts
import { registerServerObservability } from '@funcef-componentes/observability/server';

export async function register() {
  await registerServerObservability({ serviceName: 'meu-app' });
}
```

Traces exportados ao Azure Monitor com filtro de ruído (assets do Next,
scanners/bots, métodos exóticos; **5xx nunca é filtrado**).

### 3. next.config

```ts
import { observabilityConnectSrc, observabilityServerPackages } from '@funcef-componentes/observability/next-config';

// CSP: ...connect-src [...observabilityConnectSrc]
// serverExternalPackages: [...observabilityServerPackages]
```

NÃO adicione `@funcef-componentes/observability` em `serverExternalPackages`
— externalizar o pacote quebraria o boundary `'use client'` do entry `.`.

## Env (fallback zero-config)

| Variável                                    | Lado     | Efeito                                          |
| ------------------------------------------- | -------- | ----------------------------------------------- |
| `NEXT_PUBLIC_APPINSIGHTS_CONNECTION_STRING` | browser  | liga a telemetria de browser                    |
| `APPLICATIONINSIGHTS_CONNECTION_STRING`     | servidor | liga o OTel no servidor                         |
| `NEXT_PUBLIC_API_URL`                       | browser  | host excluído dos headers de correlação         |
| `OTEL_DEBUG=true`                           | servidor | loga no stdout os spans descartados pelo filtro |

Config explícita (props/options) tem precedência sobre a env.

## Remover a telemetria

```bash
pnpm remove @funcef-componentes/observability
```

E apague os 3 pontos de contato acima. Nada mais.
